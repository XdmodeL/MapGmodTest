player_manager.AddValidModel( "sm", 				"models/sm/sm.mdl" )
list.Set( "PlayerOptionsModel",  "sm",				"models/sm/sm.mdl" )