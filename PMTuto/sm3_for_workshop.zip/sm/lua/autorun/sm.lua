player_manager.AddValidModel( "stick_man", "models/sm/sm.mdl" )
list.Set( "PlayerOptionsModel",  "stick_man", "models/sm/sm.mdl" )